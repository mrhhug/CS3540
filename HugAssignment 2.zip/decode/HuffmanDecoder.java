package decode;
import java.io.Serializable;
import java.util.BitSet;

/**
 * @author Michael Hug hmichae4@students.kennesaw.edu
 */
public class HuffmanDecoder implements Serializable
{
    public String decode(BitSet bitCode, strippedNode root) //returns string
    {
        strippedNode sn = root; //set the first node to root
        String str = ""; //smpty string we will return later
        for(int i =0;i<=bitCode.length()+1;i++) //for loop that lasts as long as given bitset
        {
            if(sn.left==sn.right) //only way left and right can be equal if they are null
            {
                str+=sn.element; //we found a leaf, add it to string
                sn=root; //reset to root node
            }
            if(bitCode.get(i)) //found a 1, go right
            {
                sn=sn.right; //travel down our tree
            }
            else //this is 0 by elimination
            {
                sn=sn.left; //travel down our tree
            }
        }
        return str; //return the concatenated string
    }
}
