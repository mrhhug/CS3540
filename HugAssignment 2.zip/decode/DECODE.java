package decode;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.BitSet;

/**
 * @author Michael Hug hmichael4@students.kennesaw.edu
 */
public class DECODE 
{
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException
    {
        if(args.length!=3) //need 3 arguments and only 3 arguments
        {
            System.out.println("Please enter 3 arguments in the following order: 'output file for string' 'strippedNode root' 'inputfile for BitSet'");
            System.exit(1); //fail
        }
        
        FileInputStream fin = new FileInputStream(args[1]);
        ObjectInputStream ois = new ObjectInputStream(fin);
        strippedNode sn = (strippedNode) ois.readObject();
        
        /*****************************************************
         * compiler views the strippedNode classes in the
         * 2 packages to be different
         */
        ois.close();
        
        FileInputStream fin1 = new FileInputStream(args[2]);
        ObjectInputStream ois1 = new ObjectInputStream(fin1);
        BitSet bs = (BitSet) ois1.readObject();
        ois.close();
        
        HuffmanDecoder decoder = new HuffmanDecoder();
        writeCodeToFile(decoder.decode(bs,sn),args[0]);
    }
    private static void writeCodeToFile(String n, String fileName) throws FileNotFoundException, IOException
    {
        //should really add try catch with proper errors
        BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
        out.write(n);
        out.close();
    }
}


/*************************************************
50/50 Please see my comments in your code. 
*/