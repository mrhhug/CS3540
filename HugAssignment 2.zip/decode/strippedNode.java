package decode;
import java.io.Serializable;

/**
 * @author Michael Hug hmichae4@students.kennesaw.edu
 */
public class strippedNode implements Serializable//minimize the data need to transmit
{
    char element;
    strippedNode left;
    strippedNode right;
    
    public strippedNode() //This is a node for transport
    {
    }

}
