package encode;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author Michael Hug hmichae4@students.kennesaw.edu
 */
public class ENCODE 
{
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException
    {
        if(args.length!=3) //need 3 arguments and only 3 arguments
        {
            System.out.println("Please enter 3 arguments in the following order: 'input file' 'outputfile for strippedNode root' 'outputfile for bitSet'");
            System.exit(1); //fail
        }
        String str0 = new Scanner(new File(args[0])).useDelimiter("\\Z").next(); //take file as string
        HuffmanEncoder.HuffmanEncoder(str0, args[1], args[2]); //pass control to the Huffman encoder
    }
}
