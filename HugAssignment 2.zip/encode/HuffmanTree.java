package encode;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;

/*
 * This class was made way easier to use.
 * Made most of the methods private becasue interaction is minimized
 * The way it was before Main needed to call all types of methods
 * Now this class requires little interaction from Main and takes off all on it's own
 */
public class HuffmanTree implements Serializable
{

    private bloatedNode root; //the head of the tree

    public HuffmanTree(String s) 
    {
        Heap<bloatedNode> h = createHeap(createFrequencies(s)); // create a heap from supplied string
        root = constructTree (h); //changes a heap into a huffmantree
        constructCodeStrings(); //this will write the correct code to each node
    }
    
    private int[] createFrequencies(String string) //moved this from the main method to make the class easier to use
    {
        int[] fq = new int[256]; // 256 is the total number of possible chars
        /*
         * This section needs extra clarification
         * The array is 257 length.
         * The total number of chars in java is 257
         * So when a char is found incrament the array at position of numerical representation of char
         */
        for (int i = 0; i < string.length(); i++) // loop ends at end of string
        {
            fq[string.charAt(i)]++; //parses string to incrament at correct location
        }
        return fq;
    }

    private void constructCodeStrings() // method to start recursion
    {
        if (root != null) //check extreme cases
        {
            generateCodeStrings (root); //kick off recursion
        }
    }

    private void generateCodeStrings(bloatedNode n) //recursivly writes the code to each node
    {
        if (n.left != null) //null means this is a leaf
        {
            n.left.code = n.code + "0"; //left is 0
            n.right.code = n.code + "1"; //right is 1
            generateCodeStrings (n.left); // recurse on left side
            generateCodeStrings (n.right); // recurse on right side
        }
    }

    private bloatedNode constructTree(Heap<bloatedNode> h) //changes the heap into a huffmantree root
    {
        bloatedNode result = null; // initally set to null
        while (h.getSize() > 1) //make sure there are at least 2 to compare
        {
            bloatedNode n1 = h.remove(); // remove 1 bloatednode
            bloatedNode n2 = h.remove(); // remove another bloatednode
            bloatedNode n = new bloatedNode (n1.weight + n2.weight, n1, n2); //make new bloated node with children of 2 previous nodes
            h.add(n); //add the new node to the heap 
        }
        if (h.getSize() > 0) //there is one node on the heap
        {
            result = h.remove(); // remove the single node
        }
        return result; // return the root of the tree
    }

    private Heap<bloatedNode> createHeap(int[] frequencies) //returns a heap of bloatedNodes
    {
        Heap<bloatedNode> h = new Heap<>(); // creates the heap of bloatedNodes
        for (int i = 0; i < frequencies.length; i++) // for loop that terminated at the length of the int array
        {
            if (frequencies[i] > 0) // checks if the char occured
            {
                bloatedNode n = new bloatedNode ((char)i, frequencies[i]);  //creates bloatednode with correct initial element and weight
                h.add(n); // add to the heap, recall the compareTo method makes this a min heap
            }
        }
        return h;
    }

    /**
     * precondition: s is not null
     * @param s
     * @return
     */
    public HuffmanCode getCompressedDocument(String s) //given method for string to bitSet
    {
        s = generateCodeAsString(s); //calling helper method
        HuffmanCode hc = new HuffmanCode(s.length()); //creates a new Huffmancode / bitSet
        for (int i = 0; i < s.length(); i++) //for loop that terminated at legth of string
        {
            hc.add (s.charAt(i)); //helper method that will set 1 if need be on the bitSet in the huffmancode
        }
        return hc; //return huffmancode
    }

    private String generateCodeAsString(String s) //returns a string of 0,1 that will in turn be a bitSet
    //normally just go straight for the bitSet, but string to bitSet method already written; sticking to framework
    {
        String str = ""; //empty string
        for (int i =0;i<s.length();i++) // for loop that lasts as long as supplied string
        {
            str+=findCodeOfNodeGivenChar(s.charAt(i)); // concatenate next char with pervious char
        }
        return str; //return 1,0 string
    }

    private String findCodeOfNodeGivenChar(char c) //breadth first search is most efficeint, utilizing the huffmantree data structure correctly
    {
        Queue<bloatedNode> queue = new LinkedList<>(); //queues are for BFS
        queue.add(root); // start the queue with the root
        while (!queue.isEmpty()) // end the loop when out of nodes
        {
            if(queue.peek().element==c) //this is the target char
            {
                return queue.peek().code; //terminate early because of success! recall that a char can only occur at one node
            }
            if (queue.peek().left!=null) //check for left child
            {
                queue.add(queue.peek().left); //add left child to queue
            }
            if (queue.peek().right!=null) //check for right child
            {
                queue.add(queue.peek().right); //add right child to queue
            }
            queue.remove(); // done with the current node
        }
        //should never really get here, the code is automated enough that something crazy would have to happen
        return null; //if we did not terminate early we did not find the char. the code of the char is null
    }
    
    public bloatedNode getRoot() //returns the root of the tree
    {
        return root; //very useful when stripping down for transport
    }
}
