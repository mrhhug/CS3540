package encode;
import java.io.Serializable;

/**
 * @author Michael Hug hmichae4@students.kennesaw.edu
 */
public class bloatedNode implements Serializable, Comparable<bloatedNode> //this is the node we need to build the HT/HC
{
    char element; //simply the char
    int weight; //total occurances of element, or combined elements if this node is not a leaf
    bloatedNode left; //left child
    bloatedNode right; //right child
    String code = ""; //will be used to address the node using 0,1 and a traversal of lefts and rights
    
    /********************************************
     * instance fields should not be visible
     */

    /**
     * preconditions: weight > 0
     * @param ch
     * @param weight
     * @throws IllegalArgumentException if weight <= 0
     */
    public bloatedNode (char ch, int weight)
    {
            if (weight <= 0)
            {
                throw new IllegalArgumentException ("invalid weight");
            }
            this.element = ch;
            this.weight = weight;
    }

    /**
     * preconditions: weight > 0
     * @param ch
     * @param weight
     * @throws IllegalArgumentException if weight <= 0
     */
    public bloatedNode (int weight, bloatedNode left, bloatedNode right)
    {
            if (weight <= 0) 
            {
                throw new IllegalArgumentException ("invalid weight");
            }
            this.weight = weight;
            this.left = left;
            this.right = right;
    }
    /*
     * override method to make heap act the way we want
     * gives us a min heap
     */
    @Override
    public int compareTo(bloatedNode t) 
    {
        if(t.weight>weight) //toggle the inequality to reverse ordering
        {
            return 1;
        }
        return -1;
    }
    
    public strippedNode convert() //public method to convert from bloatedNodes to strippedNode
    {
        return convert(this); //kick off the recursion
    }
    
    private strippedNode convert(bloatedNode bn) //recursivly convert from bloatedNodes to strippedNode
    {
        strippedNode sn = new strippedNode(); //create the new strippedNode
        sn.element=bn.element; //set the elements(char) equal
        if(bn.left!=null) // check for left child
        {
            sn.left=convert(bn.left); //left child found, recurse
        }
        if(bn.right!=null) // check for right child
        {
            sn.right=convert(bn.right); //right child found, recurse
        }
        return sn; //this returns the root and therefor the entire tree
    }
}
