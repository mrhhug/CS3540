package encode;
import java.io.Serializable;
import java.util.BitSet;


public class HuffmanCode implements Serializable
{

    private BitSet bitCode;
    //changed this from size and added method to return only the bitset.
    private int iterator; //bitSet contains a length method, this was not always the true length anyway in previous implementations

    public HuffmanCode (int length) //we are initializing the size to get exactly the num bits we want
    {
        bitCode = new BitSet(length); //this makes getbitset().length() accurate
        iterator = 0; //this is what we use to toggle the bits
    }

    public void add (char ch)
    {
        if (ch == '1') //we need to toggle
        {
            bitCode.set(iterator); //toggle at location of iterator
        }
        iterator++; //incrament
    }
    
    public BitSet getBitset() //This returns only the bitset. to keep the size of the file down.
    {
        return bitCode; //bitset also can return size.
    }
}
