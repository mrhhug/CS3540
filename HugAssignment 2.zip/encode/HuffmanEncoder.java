package encode;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.BitSet;

/**
 * @author Michael Hug hmichae4@students.kennesaw.edu
 */
public class HuffmanEncoder 
{
    public static void HuffmanEncoder(String s0, String s1, String s2) throws FileNotFoundException, IOException, ClassNotFoundException
    {
        HuffmanTree t = new HuffmanTree (s0);
        HuffmanCode code = t.getCompressedDocument(s0);
        
        writeCodeToFile (t.getRoot().convert(), s1);
        writeCodeToFile (code.getBitset(), s2);

        /*this could be in another file/computer 
         the decoder also needs the tree*/
        //FileInputStream fin = new FileInputStream(args[1]);
        //ObjectInputStream ois = new ObjectInputStream(fin);
        //HuffmanCode code2 = (HuffmanCode) ois.readObject();
        //ois.close();

        //BitSet bs = new BitSet();
        //bs = code2.getBitset();


        /*
        strippedNode snRoot = new strippedNode();
        snRoot = t.getRoot().convert();
        System.out.println();
        HuffmanDecoder decoder = new HuffmanDecoder();
        System.out.println(decoder.decode(code.getBitset(),snRoot));*/

    }
    
    private static void writeCodeToFile(strippedNode n, String fileName) throws FileNotFoundException, IOException
    {
        //should really add try catch with proper errors
        ObjectOutputStream output = new ObjectOutputStream (new FileOutputStream (fileName));
        output.writeObject(n);
        output.close();
    }

    private static void writeCodeToFile(BitSet bs, String fileName) throws FileNotFoundException, IOException
    {
        //should really add try catch with proper errors
        ObjectOutputStream output = new ObjectOutputStream (new FileOutputStream (fileName));
        output.writeObject(bs);
        output.close();
    }
}
