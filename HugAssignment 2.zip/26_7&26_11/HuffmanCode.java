import java.io.Serializable;
import java.util.BitSet;


public class HuffmanCode implements Serializable
{

	private BitSet bitCode;
	private int size;
	
	public HuffmanCode ()
	{
		bitCode = new BitSet();
		size = 0;
	}
	
	public void add (char ch)
	{
		if (ch == '1')
			bitCode.set(size);
		size++;
	}
}
