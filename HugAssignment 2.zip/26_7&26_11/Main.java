/**
 * @author hmichea4@students.kennesaw.edu
 */
public class Main {

    public static void main(String[] args) {
       BinaryTree<Character> BT = new BinaryTree();
       BT.insert('F');
       BT.insert('B');
       BT.insert('J');
       //BT.insert('H');
       BT.insert('A');
       BT.insert('D');
       BT.insert('K');
       BT.insert('C');
       BT.insert('E');
       
       BT.preorder();
       System.out.print("\n");
       BT.postorder();
       System.out.print("\n");
       BT.inorder();
       System.out.print("\n");
       
       BinaryTree<Character> BT2 = new BinaryTree();
       BT2.clone(BT);
       System.out.print("\n");
       System.out.print("\n");
       BT2.preorder();
       System.out.print("\n");
       BT2.postorder();
       System.out.print("\n");
       BT2.inorder();
       System.out.print("\n");
       System.out.print(BT.getNumberOfLeaves());
       System.out.print(BT.getNumberOfNONLeaves());
       BT.delete('K');
       BT.insert('L');
       System.out.print(BT2.equals(BT));
       System.out.print("\n");
       BT2.inorder();
       System.out.print("\n");
       BT.inorder();
    }
}


/************************************************
50/50 - number of non-leaves

34/50 - clone & equals
*/